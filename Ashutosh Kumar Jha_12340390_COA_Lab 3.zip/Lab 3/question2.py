def binary_to_decimal(binary,bits):
    value = int(binary,2)
    if binary[0]=='1':
        value = value-(1<<bits)
    return value

def booth_multiplication(n, binary1, binary2):
    M = binary_to_decimal(binary1, n)
    Q = binary_to_decimal(binary2, n)

    A = 0
    Q_1 = 0
    count = n

    while count > 0:
        Q_0 = Q & 1
        if Q_0 == 1 and Q_1 == 0:
            A = A - M ##since both are decimals, the AddSub function cannot be used to compute the difference since it accepts binary strings
        elif Q_0 == 0 and Q_1 == 1:
            A = A + M ##since both are decimals, the AddSub funcion cannot be used to compute the difference since it accepts binary strings 

        A, Q, Q_1 = (A >> 1), (Q >> 1) | ((A & 1) << (n - 1)), (Q_0)


        count -= 1

    ##result variable is used to store the decimal result of computation
    result = (A << n) | Q 
    ##result_binary variable is used to store the binary result of computation
    result_binary = format(result & ((1 << (2 * n)) - 1), f'0{2 * n}b')

    return result_binary

if __name__=="__main__":
    
    n = int(input("Enter the number of bits you want to use: "))
    binary1 = input("Enter the first binary number: ")
    binary2 = input("Enter the second binary number: ")
    result = booth_multiplication(n,binary1,binary2)
    print(f"Result in binary: {result}")
    print(f"Result in decimal: {binary_to_decimal(result,n)}")

